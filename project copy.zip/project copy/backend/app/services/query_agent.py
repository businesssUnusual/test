# # # _history = []

# # # def answer_query(question: str) -> str:
# # #     answer = f"(Simulated) Answer to: {question}"
# # #     _history.append({"question": question, "answer": answer})
# # #     return answer

# # # def get_history():
# # #     return _history
# # from datetime import datetime
# # from app.db.database import get_db

# # async def answer_query(question: str) -> str:
# #     db = get_db()
# #     answer = f"(Simulated) Answer to: {question}"
# #     entry = {
# #         "question": question,
# #         "answer": answer,
# #         "timestamp": datetime.utcnow()
# #     }
# #     await db["queries"].insert_one(entry)
# #     return answer

# # async def get_history():
# #     db = get_db()
# #     return await db["queries"].find({}).sort("timestamp", -1).to_list(100)

# # from datetime import datetime
# # from app.db.database import get_db
# # from app.utils.serialization import convert_mongo_ids

# # async def answer_query(question: str) -> str:
# #     db = get_db()
# #     answer = f"(Simulated) Answer to: {question}"
# #     entry = {
# #         "question": question,
# #         "answer": answer,
# #         "timestamp": datetime.utcnow()
# #     }
# #     await db["queries"].insert_one(entry)
# #     return answer

# # async def get_history():
# #     db = get_db()
# #     history = await db["queries"].find({}).sort("timestamp", -1).to_list(100)
# #     return convert_mongo_ids(history)

# from datetime import datetime
# from app.db.database import get_db
# from app.utils.serialization import convert_mongo_ids
# from app.services.pdf_parser import extract_text_from_all_pdfs
# import os
# import openai
# from dotenv import load_dotenv

# load_dotenv()
# openai.api_key = os.getenv("OPENAI_API_KEY")

# async def answer_query(question: str) -> str:
#     db = get_db()

#     # Combine contents from all PDFs in uploaded_files dir
#     context = extract_text_from_all_pdfs("uploaded_files")

#     try:
#         completion = client.chat.completions.create(
#             model="gpt-4",
#             messages=[
#                 {"role": "system", "content": "You are an assistant that answers questions about financial documents."},
#                 {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}
#             ]
#         )
#         answer = completion.choices[0].message.content.strip()
#     except Exception as e:
#         answer = f"Error while querying OpenAI: {str(e)}"

#     entry = {
#         "question": question,
#         "answer": answer,
#         "timestamp": datetime.utcnow()
#     }
#     await db["queries"].insert_one(entry)
#     return answer

# async def get_history():
#     db = get_db()
#     history = await db["queries"].find({}).sort("timestamp", -1).to_list(100)
#     return convert_mongo_ids(history)


from datetime import datetime
from app.db.database import get_db
from app.utils.serialization import convert_mongo_ids
from app.services.pdf_parser import extract_text_from_all_pdfs
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()

# ✅ Create the client instance using the new OpenAI SDK
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
print(os.getenv("OPENAI_API_KEY"))
async def answer_query(question: str) -> str:
    db = get_db()

    # ✅ Combine contents from all PDFs in uploaded_files dir
    context = extract_text_from_all_pdfs("uploaded_files")

    try:
        # ✅ Use the new SDK's method to make the chat request
        completion = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an assistant that answers questions about financial documents."},
                {"role": "user", "content": f"Context:\n{context}\n\nQuestion: {question}"}
            ]
        )
        answer = completion.choices[0].message.content.strip()
    except Exception as e:
        answer = f"Error while querying OpenAI: {str(e)}"

    entry = {
        "question": question,
        "answer": answer,
        "timestamp": datetime.utcnow()
    }
    await db["queries"].insert_one(entry)
    return answer

async def get_history():
    db = get_db()
    history = await db["queries"].find({}).sort("timestamp", -1).to_list(100)
    return convert_mongo_ids(history)
