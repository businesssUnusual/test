import fitz  # PyMuPDF
import os

def extract_text_from_all_pdfs(directory):
    all_text = []
    for file in os.listdir(directory):
        if file.endswith(".pdf"):
            path = os.path.join(directory, file)
            text = extract_text_from_pdf(path)
            all_text.append(f"--- {file} ---\n{text}")
    return "\n\n".join(all_text)

def extract_text_from_pdf(pdf_path):
    try:
        doc = fitz.open(pdf_path)
        text = "\n".join([page.get_text() for page in doc])
        doc.close()
        return text
    except Exception as e:
        return f"[Error parsing {pdf_path}: {e}]"
