# # # import os
# # # import shutil
# # # from fastapi import UploadFile

# # # UPLOAD_DIR = "uploaded_files"
# # # os.makedirs(UPLOAD_DIR, exist_ok=True)

# # # # ✅ Function to process and save uploaded files
# # # async def process_files(files: list[UploadFile]):
# # #     saved = []
# # #     for file in files:
# # #         path = os.path.join(UPLOAD_DIR, file.filename)
# # #         with open(path, "wb") as f:
# # #             shutil.copyfileobj(file.file, f)
# # #         saved.append({"filename": file.filename})
# # #     return saved

# # # # ✅ Function to list uploaded files
# # # def list_uploaded_files():
# # #     return [{"filename": f} for f in os.listdir(UPLOAD_DIR) if not f.startswith(".")]

# # import os
# # import shutil
# # from datetime import datetime
# # from fastapi import UploadFile
# # from app.db.database import get_db

# # UPLOAD_DIR = "uploaded_files"
# # os.makedirs(UPLOAD_DIR, exist_ok=True)

# # async def process_files(files):
# #     db = get_db()
# #     saved = []
# #     for file in files:
# #         path = os.path.join(UPLOAD_DIR, file.filename)
# #         with open(path, "wb") as f:
# #             shutil.copyfileobj(file.file, f)
# #         metadata = {
# #             "filename": file.filename,
# #             "upload_time": datetime.utcnow(),
# #             "path": path
# #         }
# #         await db["files"].insert_one(metadata)
# #         saved.append(metadata)
# #     return saved

# import os
# import shutil
# from datetime import datetime
# from fastapi import UploadFile
# from app.db.database import get_db

# UPLOAD_DIR = "uploaded_files"
# os.makedirs(UPLOAD_DIR, exist_ok=True)

# async def process_files(files):
#     db = get_db()
#     saved = []
#     for file in files:
#         path = os.path.join(UPLOAD_DIR, file.filename)
#         with open(path, "wb") as f:
#             shutil.copyfileobj(file.file, f)
#         metadata = {
#             "filename": file.filename,
#             "upload_time": datetime.utcnow(),
#             "path": path
#         }
#         await db["files"].insert_one(metadata)
#         saved.append(metadata)
#     return saved
import os
import shutil
from datetime import datetime
from fastapi import UploadFile

from app.db.database import get_db  # ✅ Required for DB connection
from app.utils.serialization import convert_mongo_ids  # ✅ For ObjectId -> str

UPLOAD_DIR = "uploaded_files"
os.makedirs(UPLOAD_DIR, exist_ok=True)

async def process_files(files):
    db = get_db()
    saved = []
    for file in files:
        path = os.path.join(UPLOAD_DIR, file.filename)
        with open(path, "wb") as f:
            shutil.copyfileobj(file.file, f)

        metadata = {
            "filename": file.filename,
            "upload_time": datetime.utcnow(),
            "path": path
        }

        result = await db["files"].insert_one(metadata)
        metadata["_id"] = result.inserted_id  # Add ID for response
        saved.append(metadata)

    return convert_mongo_ids(saved)  # ✅ Clean ObjectId before returning
