# # _tasks = [
# #     {"id": 1, "title": "Missing Q2 report for client A"},
# #     {"id": 2, "title": "Verify KYC document for client B"},
# # ]

# # def get_outstanding_tasks():
# #     return _tasks
# from app.db.database import get_db

# async def get_outstanding_tasks():
#     db = get_db()
#     tasks = await db["tasks"].find({}).to_list(100)
#     return tasks

from app.db.database import get_db
from app.utils.serialization import convert_mongo_ids

async def get_outstanding_tasks():
    db = get_db()
    tasks = await db["tasks"].find({}).to_list(100)
    return convert_mongo_ids(tasks)