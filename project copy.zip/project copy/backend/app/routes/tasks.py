# # # backend/app/routes/tasks.py
# # from fastapi import APIRouter
# # from app.services.task_manager import get_outstanding_tasks

# # router = APIRouter()

# # @router.get("/")
# # async def list_tasks():
# #     return get_outstanding_tasks()
# from fastapi import APIRouter
# from app.services.task_manager import get_outstanding_tasks

# router = APIRouter()

# @router.get("/")
# async def list_tasks():
#     return await get_outstanding_tasks()

from fastapi import APIRouter
from app.services.task_manager import get_outstanding_tasks

router = APIRouter()

@router.get("/")
async def list_tasks():
    return await get_outstanding_tasks()