# # # backend/app/routes/query.py
# # from fastapi import APIRouter
# # from pydantic import BaseModel
# # from app.services.query_agent import answer_query, get_history

# # router = APIRouter()

# # class QueryRequest(BaseModel):
# #     question: str

# # @router.post("/")
# # async def query_client(request: QueryRequest):
# #     return answer_query(request.question)

# # @router.get("/history")
# # async def query_history():
# #     return get_history()
# from fastapi import APIRouter, Body
# from app.services.query_agent import answer_query, get_history

# router = APIRouter()

# @router.post("/")
# async def handle_query(question: str = Body(...)):
#     answer = await answer_query(question)
#     return {"response": answer}

# @router.get("/history")
# async def query_history():
#     return await get_history()

# def convert_mongo_ids(docs):
#     for doc in docs:
#         doc["_id"] = str(doc["_id"])
#     return docs

# from fastapi import APIRouter, Body
# from app.services.query_agent import answer_query, get_history

# router = APIRouter()

# @router.post("/")
# async def handle_query(question: str = Body(...)):
#     answer = await answer_query(question)
#     return {"response": answer}

# @router.get("/history")
# async def query_history():
#     return await get_history()

from fastapi import APIRouter, Body
from app.services.query_agent import answer_query, get_history

router = APIRouter()

@router.post("/")
async def ask_query(payload: dict = Body(...)):
    question = payload.get("question", "")
    if not question:
        return {"error": "No question provided"}
    
    answer = await answer_query(question)
    return {"question": question, "answer": answer}

@router.get("/query/history")
async def query_history():
    return await get_history()
