# # # backend/app/routes/files.py
# # from fastapi import APIRouter, UploadFile, File
# # from app.services.file_processor import process_files, list_uploaded_files

# # router = APIRouter()

# # @router.post("/")
# # async def upload_files(files: list[UploadFile] = File(...)):
# #     return await process_files(files)

# # @router.get("/")
# # async def get_uploaded_files():
# #     return list_uploaded_files()
# from fastapi import APIRouter, UploadFile, File
# from app.services.file_processor import process_files
# from app.db.database import get_db

# router = APIRouter()

# @router.post("/")
# async def upload_files(files: list[UploadFile] = File(...)):
#     return await process_files(files)

# @router.get("/")
# async def list_uploaded_files():
#     db = get_db()
#     files = await db["files"].find({}).sort("upload_time", -1).to_list(100)
#     # Convert ObjectId to string
#     for f in files:
#         f["_id"] = str(f["_id"])
#     return files


from fastapi import APIRouter, UploadFile, File
from app.services.file_processor import process_files
from app.db.database import get_db
from app.utils.serialization import convert_mongo_ids
from bson import ObjectId

from fastapi import APIRouter, HTTPException
import os


router = APIRouter()

@router.post("/")
async def upload_files(files: list[UploadFile] = File(...)):
    return await process_files(files)

@router.get("/")
async def list_uploaded_files():
    db = get_db()
    files = await db["files"].find({}).sort("upload_time", -1).to_list(100)
    return convert_mongo_ids(files)

@router.delete("/{file_id}")
async def delete_file(file_id: str):
    db = get_db()
    file = await db["files"].find_one({"_id": ObjectId(file_id)})

    if not file:
        raise HTTPException(status_code=404, detail="File not found")

    file_path = file.get("path")
    if file_path and os.path.exists(file_path):
        os.remove(file_path)

    await db["files"].delete_one({"_id": ObjectId(file_id)})
    return {"message": "File deleted successfully"}