# import motor.motor_asyncio
# import os
# from dotenv import load_dotenv

# load_dotenv()

# MONGO_URL = os.getenv("DB_URL", "mongodb://localhost:27017")
# DB_NAME = os.getenv("DB_NAME", "clientinfo")

# client = None

# def get_db():
#     return client[DB_NAME] if client else None

# async def connect_db():
#     global client
#     client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
#     print("✅ MongoDB connected")

# async def close_db():
#     global client
#     if client:
#         client.close()
#         print("🔌 MongoDB disconnected")
import motor.motor_asyncio
import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URL = os.getenv("DB_URL", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "clientinfo")

client = None

def get_db():
    return client[DB_NAME] if client else None

async def connect_db():
    global client
    client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URL)
    print("✅ MongoDB connected")

async def close_db():
    global client
    if client:
        client.close()
        print("🔌 MongoDB disconnected")