# # # from fastapi import FastAPI
# # # from fastapi.middleware.cors import CORSMiddleware
# # # from app.routes import files, tasks, query

# # # app = FastAPI()

# # # app.add_middleware(
# # #     CORSMiddleware,
# # #     allow_origins=["*"],
# # #     allow_credentials=True,
# # #     allow_methods=["*"],
# # #     allow_headers=["*"],
# # # )

# # # app.include_router(files.router, prefix="/upload", tags=["Files"])
# # # app.include_router(tasks.router, prefix="/tasks", tags=["Tasks"])
# # # app.include_router(query.router, prefix="/query", tags=["Query"])

# # from fastapi import FastAPI
# # from fastapi.middleware.cors import CORSMiddleware
# # from fastapi.staticfiles import StaticFiles
# # from starlette.responses import FileResponse
# # import os

# # from app.routes import files, tasks, query

# # app = FastAPI()

# # # Allow frontend to call backend APIs
# # app.add_middleware(
# #     CORSMiddleware,
# #     allow_origins=["*"],
# #     allow_credentials=True,
# #     allow_methods=["*"],
# #     allow_headers=["*"],
# # )

# # # Include API routes
# # app.include_router(files.router, prefix="/upload", tags=["Files"])
# # app.include_router(tasks.router, prefix="/tasks", tags=["Tasks"])
# # app.include_router(query.router, prefix="/query", tags=["Query"])

# # # Serve built frontend from React if available
# # frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../frontend/dist"))
# # if os.path.exists(frontend_dir):
# #     app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")

# #     @app.get("/")
# #     async def serve_root():
# #         return FileResponse(os.path.join(frontend_dir, "index.html"))

# from fastapi import FastAPI
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.staticfiles import StaticFiles
# from starlette.responses import FileResponse
# import os

# from app.routes import files, tasks, query
# from app.db.database import connect_db, close_db

# app = FastAPI()

# # Connect to MongoDB at startup
# @app.on_event("startup")
# async def startup_event():
#     await connect_db()

# # Close MongoDB connection at shutdown
# @app.on_event("shutdown")
# async def shutdown_event():
#     await close_db()

# # Allow frontend to call backend APIs
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # Include API routes
# app.include_router(files.router, prefix="/upload", tags=["Files"])
# app.include_router(tasks.router, prefix="/tasks", tags=["Tasks"])
# app.include_router(query.router, prefix="/query", tags=["Query"])

# # Serve built frontend from React if available
# frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../frontend/dist"))
# if os.path.exists(frontend_dir):
#     app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")

#     @app.get("/")
#     async def serve_root():
#         return FileResponse(os.path.join(frontend_dir, "index.html"))
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse
import os

from app.routes import files, tasks, query
from app.db.database import connect_db, close_db

app = FastAPI()

# Connect to MongoDB at startup
@app.on_event("startup")
async def startup_event():
    await connect_db()

# Close MongoDB connection at shutdown
@app.on_event("shutdown")
async def shutdown_event():
    await close_db()

# Allow frontend to call backend APIs
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # for development, later restrict to frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API routes
app.include_router(files.router, prefix="/upload", tags=["Files"])
app.include_router(tasks.router, prefix="/tasks", tags=["Tasks"])
app.include_router(query.router, prefix="/query", tags=["Query"])

# Serve built frontend from React if available
frontend_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../frontend/dist"))
if os.path.exists(frontend_dir):
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")

    @app.get("/")
    async def serve_root():
        return FileResponse(os.path.join(frontend_dir, "index.html"))