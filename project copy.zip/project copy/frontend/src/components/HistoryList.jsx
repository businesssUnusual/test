// import React, { useEffect, useState } from 'react';
// import axios from '../api';

// const HistoryList = () => {
//   const [history, setHistory] = useState([]);

//   useEffect(() => {
//     axios.get('/query/history').then(res => setHistory(res.data));
//   }, []);

//   return (
//     <div className="p-4 border rounded-lg shadow-md">
//       <h2 className="text-lg font-bold mb-2">Query History</h2>
//       <ul className="list-disc ml-5 text-sm text-gray-600">
//         {history.map((item, index) => (
//           <li key={index}>{item.question} → {item.answer}</li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default HistoryList;
import React from 'react';

const HistoryList = ({ history }) => {
  if (!Array.isArray(history)) return null;

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">History</h2>
      {history.length === 0 ? (
        <p>No history found.</p>
      ) : (
        <ul className="space-y-2">
          {history.map((item, index) => (
            <li key={index} className="bg-white rounded shadow p-3">
              {JSON.stringify(item)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default HistoryList;
