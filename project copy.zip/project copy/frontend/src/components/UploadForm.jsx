import React, { useState } from 'react';
import axios from '../api';

const UploadForm = () => {
  const [files, setFiles] = useState([]);

  const handleFileChange = (e) => {
    setFiles([...e.target.files]);
  };

  const handleUpload = async () => {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    await axios.post('/upload/', formData);
    alert('Files uploaded successfully');
  };

  return (
    <div className="p-4 border rounded-lg shadow-md">
      <h2 className="text-lg font-bold mb-2">Upload Client Files</h2>
      <input type="file" multiple onChange={handleFileChange} className="block mb-2" />
      <button
        onClick={handleUpload}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Upload Files
      </button>
    </div>
  );
};

export default UploadForm;