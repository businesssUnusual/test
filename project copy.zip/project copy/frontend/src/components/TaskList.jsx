            // import React, { useEffect, useState } from 'react';
            // import axios from '../api';
            
            // const TaskList = () => {
            //   const [tasks, setTasks] = useState([]);
            
            //   useEffect(() => {
            //     axios.get('/tasks/').then(res => setTasks(res.data.tasks));
            //   }, []);
            
            //   return (
            //     <div className="tasklist p-4 border rounded-lg shadow-md">
            //       <h2 className="text-lg font-bold mb-2">Outstanding Tasks</h2>
            //       <ul className="list-disc ml-5">
            //         {tasks.map(task => (
            //           <li key={task.id}>{task.description} - <strong>{task.status}</strong></li>
            //         ))}
            //       </ul>
            //     </div>
            //   );
            // };
            
            // export default TaskList;
            import React, { useEffect, useState } from 'react';

const TaskList = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('http://localhost:8000/tasks/')
      .then(res => res.json())
      .then(data => {
        setTasks(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch tasks', err);
        setError('Could not load tasks');
        setLoading(false);
      });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Outstanding Tasks</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="text-red-500">{error}</p>}
      {tasks.length === 0 && !loading && <p>No outstanding tasks.</p>}

      <ul className="space-y-2">
        {tasks.map((task, idx) => (
          <li key={idx} className="bg-white p-3 rounded shadow">
            {task.description || JSON.stringify(task)}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TaskList;
