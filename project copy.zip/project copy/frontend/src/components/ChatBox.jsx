            import React, { useState } from 'react';
            import axios from '../api';
            
            const ChatBox = () => {
              const [input, setInput] = useState('');
              const [response, setResponse] = useState('');
            
              const handleSubmit = async (e) => {
  e.preventDefault();
  try {
    console.log("Submitting", input);
    const res = await axios.post('/query/', { question: input });
    setResponse(res.data.answer);
  } catch (err) {
    console.error("Error:", err.response?.data || err.message);
    setResponse("An error occurred while fetching the answer.");
  }
};

            
              return (
                <div className="chatbox p-4 border rounded-lg shadow-md">
                  <form onSubmit={handleSubmit} className="flex gap-2">
                    <input className="flex-1 p-2 border rounded" placeholder="Ask a question..." value={input} onChange={e => setInput(e.target.value)} />
                    <button className="bg-blue-500 text-white px-4 py-2 rounded" type="submit">Ask</button>
                  </form>
                  {response && <p className="mt-4 text-gray-700">{response}</p>}
                </div>
              );
            };
            
            export default ChatBox;