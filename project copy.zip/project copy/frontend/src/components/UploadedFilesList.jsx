// // import React, { useEffect, useState } from 'react';
// // import axios from '../api';

// // const UploadedFilesList = () => {
// //   const [files, setFiles] = useState([]);

// //   useEffect(() => {
// //     axios.get('/upload/').then(res => setFiles(res.data));
// //   }, []);

// //   return (
// //     <div className="p-4 border rounded-lg shadow-md">
// //       <h2 className="text-lg font-bold mb-2">Uploaded Files</h2>
// //       <ul className="list-disc ml-5 text-sm text-gray-600">
// //         {files.map((file, index) => (
// //           <li key={index}>{file.filename}</li>
// //         ))}
// //       </ul>
// //     </div>
// //   );
// // };

// // export default UploadedFilesList;
// import React, { useEffect, useState } from 'react';

// const UploadedFilesList = () => {
//   const [files, setFiles] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     fetch('http://localhost:8000/upload/')
//       .then(res => res.json())
//       .then(data => {
//         setFiles(Array.isArray(data) ? data : []);
//         setLoading(false);
//       })
//       .catch(err => {
//         console.error('Failed to fetch files', err);
//         setError('Could not load uploaded files');
//         setLoading(false);
//       });
//   }, []);

//   return (
//     <div className="p-4">
//       <h2 className="text-xl font-bold mb-4">Uploaded Files</h2>
//       {loading && <p>Loading...</p>}
//       {error && <p className="text-red-500">{error}</p>}
//       {files.length === 0 && !loading && <p>No files uploaded yet.</p>}

//       <ul className="space-y-2">
//         {files.map((file, idx) => (
//           <li key={idx} className="bg-white shadow px-4 py-2 rounded">
//             {file.filename}
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default UploadedFilesList;


// src/components/UploadedFilesList.jsx
import { useEffect, useState } from 'react';
import axios from 'axios';

export default function UploadedFilesList() {
  const [files, setFiles] = useState([]);

  const fetchFiles = async () => {
    try {
      const res = await axios.get('http://localhost:8000/upload/');
      setFiles(res.data);
    } catch (err) {
      console.error('Failed to fetch files:', err);
    }
  };

  const deleteFile = async (fileId) => {
    try {
      await axios.delete(`http://localhost:8000/upload/${fileId}`);
      setFiles((prev) => prev.filter((file) => file._id !== fileId));
    } catch (err) {
      console.error('Failed to delete file:', err);
    }
  };

  useEffect(() => {
    fetchFiles();
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Uploaded Files</h2>
      {files.length === 0 ? (
        <p className="text-gray-500">No files uploaded.</p>
      ) : (
        <ul className="space-y-3">
          {files.map((file) => (
            <li
              key={file._id}
              className="flex justify-between items-center border p-3 rounded shadow-sm bg-white"
            >
              <span>{file.filename}</span>
              <button
                onClick={() => deleteFile(file._id)}
                className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
