import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import QueryAssistant from './pages/QueryAssistant';
import './styles.css';
import logo from './assets/bny-logo.png';

const App = () => (
  <Router>
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow p-4 flex items-center justify-between">
        <img src={logo} alt="BNY Logo" className="h-10" />
        <nav className="space-x-4">
          <Link to="/" className="text-blue-600 hover:underline">Dashboard</Link>
          <Link to="/assistant" className="text-blue-600 hover:underline">Client Assistant</Link>
        </nav>
      </header>
      <main className="p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/assistant" element={<QueryAssistant />} />
        </Routes>
      </main>
    </div>
  </Router>
);

export default App;