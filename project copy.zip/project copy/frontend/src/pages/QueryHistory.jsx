// // src/components/QueryHistory.jsx
// import React, { useEffect, useState } from 'react';

// const QueryHistory = () => {
//   const [history, setHistory] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState('');

//   useEffect(() => {
//     fetch('http://localhost:8000/query/history')
//       .then((res) => {
//         if (!res.ok) {
//           throw new Error('Failed to fetch history');
//         }
//         return res.json();
//       })
//       .then((data) => {
//         setHistory(data || []);
//         setLoading(false);
//       })
//       .catch((err) => {
//         setError(err.message);
//         setLoading(false);
//       });
//   }, []);

//   return (
//     <div className="p-4">
//       <h2 className="text-2xl font-semibold mb-4">Query History</h2>

//       {loading && <p>Loading...</p>}
//       {error && <p className="text-red-500">Error: {error}</p>}

//       <ul className="space-y-4">
//         {history?.length === 0 && !loading && <p>No queries found.</p>}

//         {history?.map((item, index) => (
//           <li key={index} className="bg-white p-4 rounded shadow">
//             <p className="font-medium">❓ {item.question}</p>
//             <p className="text-gray-700 mt-2">💡 {item.answer}</p>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default QueryHistory;
import React, { useEffect, useState } from 'react';

const QueryHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('http://localhost:8000/query/history')
      .then(res => res.json())
      .then(data => {
        setHistory(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to fetch history', err);
        setError('Could not load query history');
        setLoading(false);
      });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Query History</h2>
      {loading && <p>Loading...</p>}
      {error && <p className="text-red-500">{error}</p>}
      {history.length === 0 && !loading && <p>No query history found.</p>}

      <ul className="space-y-3">
        {history.map((item, idx) => (
          <li key={idx} className="bg-white shadow rounded p-4">
            <p><strong>Q:</strong> {item.question}</p>
            <p><strong>A:</strong> {item.answer}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default QueryHistory;
