import React from 'react';
import ChatBox from '../components/ChatBox';

const QueryAssistant = () => (
  <div className="max-w-2xl mx-auto">
    <ChatBox />
  </div>
);

export default QueryAssistant;
