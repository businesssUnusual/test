                 import React from 'react';
                 import ChatBox from '../components/ChatBox';
                 import UploadForm from '../components/UploadForm';
                 import TaskList from '../components/TaskList';
                 
                 const Home = () => (
                   <div className="p-4 grid gap-4">
                     <UploadForm />
                     <ChatBox />
                     <TaskList />
                   </div>
                 );
                 
                 export default Home;