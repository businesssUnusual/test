import React from 'react';
import UploadForm from '../components/UploadForm';
import TaskList from '../components/TaskList';
import HistoryList from '../components/HistoryList';
import UploadedFilesList from '../components/UploadedFilesList';

const Dashboard = () => (
  <div className="grid gap-6 md:grid-cols-2">
    <div className="space-y-6">
      <UploadForm />
      <UploadedFilesList />
    </div>
    <div className="space-y-6">
      <TaskList />
      <HistoryList />
    </div>
  </div>
);

export default Dashboard;
